/*
 * HalfAdder.h
 *
 *  Created on: 21 de set de 2022
 *      Author: Aluno
 */

#ifndef HALFADDER_H_
#define HALFADDER_H_

#include <systemc.h>

SC_MODULE (HalfAdder) {
	sc_in<bool> a;
	sc_in<bool> b;
	sc_out<bool> s;
	sc_out<bool> c;

	void process(){
		s = a ^ b;
		c = a & b;
	}

	SC_CTOR(HalfAdder){
		SC_METHOD(process);
		sensitive << a << b;
	}
};

#endif /* HALFADDER_H_ */
