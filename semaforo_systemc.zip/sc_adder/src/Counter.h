/*
 * Counter.h
 *
 *  Created on: 23 de set de 2022
 *      Author: Aluno
 */

#ifndef COUNTER_H_
#define COUNTER_H_

#include <systemc.h>
#include <iostream>
using namespace std;

template<int N>
SC_MODULE (Counter) {
	sc_in_clk 	clock;
	sc_in<bool> reset;
	sc_in<bool> enable;
	sc_out<sc_uint<N> > counter_out;

	sc_uint<N> data;

	void increment_counter(){
		if(reset.read() == 1){
			data = 0;
		} else if(enable.read() == 1){
			data += 1;
			cout << "@" << sc_time_stamp() << " :: Value incremented!" << endl;
			cout << "\t data = " << data << endl;
			cout << "\t counter_out = " << counter_out.read() << endl;
		}
		counter_out.write(data);
	}

	SC_CTOR(Counter){
		SC_METHOD(increment_counter);
		sensitive << clock.pos();
	}

/*	static void testbench(const char * trace_file) {
		sc_clock  clock("clk", sc_time(2,SC_NS), 0.5, sc_time(1,SC_NS), false);
		sc_signal<bool>   reset;
		sc_signal<bool>   enable;
		sc_signal<sc_uint<N> > counter_out;

		Counter<N> counter("Contador");
		  counter.clock(clock);
		  counter.reset(reset);
		  counter.enable(enable);
		  counter.counter_out(counter_out);

		// Open VCD file
		sc_trace_file *wf = sc_create_vcd_trace_file(trace_file);
		// Dump the desired signals
		sc_trace(wf, clock, "clock");
		sc_trace(wf, reset, "reset");
		sc_trace(wf, enable, "enable");
		sc_trace(wf, counter_out, "count");

		// Initialize all variables
		reset = 0;       // initial value of reset
		enable = 0;      // initial value of enable
		sc_start(4, SC_NS);

		reset = 1;    // Assert the reset
		cout << "@" << sc_time_stamp() <<" Asserting reset\n" << endl;
		sc_start(4, SC_NS);

		cout << "@" << sc_time_stamp() <<" Asserting enable\n" << endl;
		enable = 1;  // Assert enable
		sc_start(4, SC_NS);

		enable = 0;
		reset = 0;    // De-assert the reset
		cout << "@" << sc_time_stamp() <<" De-Asserting reset and enable\n" << endl;
		sc_start(4, SC_NS);

		cout << "@" << sc_time_stamp() <<" Asserting Enable\n" << endl;
		enable = 1;  // Assert enable
		sc_start(100, SC_NS);

		cout << "@" << sc_time_stamp() <<" De-Asserting Enable\n" << endl;
		enable = 0; // De-assert enable
		sc_start(4, SC_NS);

		reset = 1;    // Assert the reset
		cout << "@" << sc_time_stamp() <<" Asserting reset\n" << endl;
		sc_start(4, SC_NS);

		reset = 0;    // De-assert the reset
		cout << "@" << sc_time_stamp() <<" De-Asserting reset\n" << endl;
		sc_start(4, SC_NS);

		cout << "@" << sc_time_stamp() <<" Terminating simulation\n" << endl;

		sc_close_vcd_trace_file(wf);
	} */
};

/*
int sc_main (int argc, char* argv[]) {
	cout << "Exemplo Contador em SystemC" << endl;

	Counter<8>::testbench("counter_8");

	return 0;// Terminate simulation
}
*/

#endif /* COUNTER_H_ */
