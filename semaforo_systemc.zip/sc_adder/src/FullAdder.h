/*
 * FullAdder.h
 *
 *  Created on: 21 de set de 2022
 *      Author: Aluno
 */

#ifndef FULLADDER_H_
#define FULLADDER_H_

#include <systemc.h>
#include "HalfAdder.h"

SC_MODULE (FullAdder) {
	sc_in<bool> a, b, carry_in;
	sc_out<bool> sum, carry_out;

	void process() {
		carry_out = _s_carry1 or _s_carry2;
	}

	SC_CTOR(FullAdder): _adder01("Adder_01"), _adder02("Adder_02") {
		SC_METHOD(process);
		sensitive << _s_carry1 << _s_carry2;

		_adder01.a(a);
		_adder01.b(b);
		_adder01.s(_s_msum);
		_adder01.c(_s_carry1);

		_adder02.a(carry_in);
		_adder02.b(_s_msum);
		_adder02.s(sum);
		_adder02.c(_s_carry2);
	}

private:
	HalfAdder _adder01;
	HalfAdder _adder02;
	sc_signal<bool> _s_msum;
	sc_signal<bool> _s_carry1;
	sc_signal<bool> _s_carry2;
};

#endif /* FULLADDER_H_ */
