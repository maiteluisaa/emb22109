/*
 * OnCarros.h
 *
 *  Created on: 23 de set de 2022
 *      Author: Aluno
 */

#ifndef ONCARROS_H_
#define ONCARROS_H_

#include <systemc.h>
#include "Counter.h"

template<int N>
SC_MODULE (OnCarros) {
	sc_in_clk clock;
	sc_in<bool> event_finished_pessoas;
	sc_in<bool> button;
	sc_out<bool> amarelo_carro;
	sc_out<bool> verde_carro;
	sc_out<bool> vermelho_carro;
	sc_out<bool> verde_pessoa;
	sc_out<bool> vermelho_pessoa;
	sc_out<bool> event_finished_car;


void process() {

	int i = 0;

	event_finished_pessoas = 0;

	_reset = 1; // resetando o contador
	_enable = 1; // habilitando o contador
	_reset = 0;

	// desligando o sem�foro dos pedestres
	verde_pessoa = 0;
	vermelho_pessoa = 1;

	// ligando o sem�foro dos carros

	amarelo_carro = 0;
	verde_carro = 1;
	vermelho_carro = 0;

	while((_counterout <= 120 or i = 1) and button != 1 ){

		if (_counterout == 127) { // condi��o para quando o contador estourar e passar de 2 minutos
			i = 1;
		}
	}

	_reset = 1; // resetando o contador
	_reset = 0;

	amarelo_carro = 1;
	verde_carro = 0;

	_enable = 1; // habilitando o contador

	while(_counterout <= 10 ){
	}

	event_finished_car = 1; // para fazer a decis�o da sa�da do sem�foro
}

SC_CTOR(OnCarros): _counter("Contador") {
		SC_METHOD(process);
		sensitive << button << _counterout;

		_counter.clock(clock);
		_counter.enable(_enable);
		_counter.reset(_reset);
		_counter.counter_out(_counterout);

	}

private:
	Counter<7> _counter; //  contador at� 127 s
	sc_signal<bool> _enable;
	sc_signal<bool> _reset;
	sc_signal<bool> _counterout;

};

#endif /* ONCARROS_H_ */
