//============================================================================
// Name        : sc_adder.cpp
// Author      : Maite
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <systemc.h>
#include "FullAdder.h"

using namespace std;

int sc_main(int argc, char* argv[]) {
	cout << "Hello SystemC" << endl; // prints

	sc_signal<bool> _a, _b, _sum;
	sc_signal<bool> _carry_in, _carry_out;

	sc_trace_file *tf = sc_create_vcd_trace_file("trace");
	sc_trace(tf, _a, "Entrada A");
	sc_trace(tf, _b, "Entrada B");
	sc_trace(tf, _carry_in, "Carry de Entrada");
	sc_trace(tf, _carry_out, "Carry de Sa�da");
	sc_trace(tf, _sum, "Sa�da");

	FullAdder	adder("Full_Adder");
	adder.a(_a);
	adder.b(_b);
	adder.sum(_sum);
	adder.carry_in(_carry_in);
	adder.carry_out(_carry_out);

	//_a = 1;
	//_b = 0;

	// registrador de 3 bits, conta de 0 at� 7

	cout << "@::" << sc_time_stamp() << " Starting Simulation." << endl;

	sc_uint<3> reg = 0;

	for(int i = 0; i < 8; i ++){
		_a.write(reg[0]);
		_b.write(reg[1]);
		_carry_in.write(reg[2]);
		cout << "Porta A: [" << _a << "]" << endl;
		cout << "Porta B: [" << _b << "]" << endl;
		cout << "Carry de Entrada: [" << _carry_in << "]" << endl;
		cout << "Carry de Sa�da: [" << _carry_out << "]" << endl;
		cout << "Sa�da: [" << _sum << "]" << endl;
		sc_start(1, SC_NS);
		reg++;
		cout << sc_time_stamp() << endl;
	}

	cout << "@::" << sc_time_stamp() << " Ending Simulation." << endl;

	sc_close_vcd_trace_file(tf);

	return 0;
}
